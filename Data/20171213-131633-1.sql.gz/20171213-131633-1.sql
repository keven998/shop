-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : rm-wz9pd52bu6p901r3jo.mysql.rds.aliyuncs.com
-- Port     : 3306
-- Database : shop
-- 
-- Part : #1
-- Date : 2017-12-13 13:16:33
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `h_access`
-- -----------------------------
DROP TABLE IF EXISTS `h_access`;
;

-- -----------------------------
-- Records of `h_access`
-- -----------------------------
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');
INSERT INTO `h_access` VALUES ('');

-- -----------------------------
-- Table structure for `h_account_log`
-- -----------------------------
DROP TABLE IF EXISTS `h_account_log`;
;


-- -----------------------------
-- Table structure for `h_action_order`
-- -----------------------------
DROP TABLE IF EXISTS `h_action_order`;
;

